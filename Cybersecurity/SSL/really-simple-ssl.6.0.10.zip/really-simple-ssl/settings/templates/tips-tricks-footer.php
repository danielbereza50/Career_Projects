<?php defined('ABSPATH') or die(); ?>

<a href="https://really-simple-ssl.com/knowledge-base-overview/" target="_blank" class="button button-secondary"><?php _e("Documentation", "really-simple-ssl"); ?></a>
